
var imageCreater={
    /**
     * @param e a object to img
     * @param description the words
     */
    newImgX:function(e,description){//img_obj string
        var ret = {};
        ret.description = description;
        ret.view_time= 0;
        ret = imageProcess(ret,e[0]);
        ret = getIDs(ret);
        ret.hover_time=0;
        ret.hover_opt="";
        ret.view_site = mPage.viewSite;
        ret.more_size = mPage.moreSize;
        ret.download_pic = mPage.downloadPic;
        ret.view_origin = mPage.viewOrigin;
        return ret;
    }
}

function getIDs(ret){
    var t = parseInt(mPage.getUrl().match(/&pn=\d+/)[0].match(/\d+/)[0]);
    ret.list_id = t;
    if(document.referrer.match(/\/index\?/) != null){
        ret.id = t;
        ret.pre = t-1;
        ret.next = t+1;
    }else{
        //TODO
        /**
         * 当点击了右侧一张图片后
         * 新的图片顺序非常的奥妙重重
         * 与原有图片顺序完全不一致
         * 而且有些图片在原有大界面可能还没有出现
         * 还要往后翻好几页
         * 估计可能是个顺序推荐系统
         */
    }
    ret.data_feature = mPage.getUrl();
    return ret;
}

console.log("Baidu onePic is Loaded!");

mPage.getUrl = function () {
    return window.location.href;
}

mPage.getQuery = function(){
    return $("#kw").val();
}

mPage.getImgObj = function(){
    return $("#currentImg");
}

mPage.getImgTitle = function(){
    return $(".pic-title").text();
}

$(".btn-download").click(mPage.onDownloadPic);
$(".pic-size").click(mPage.onMoreSize);
$(".pic-from-host").click(mPage.onViewSite);
$(".pic-title a").click(mPage.onViewSite);
$(".img-wrapper img").click(mPage.onViewSite);

/*
mPage.picUpdate = function(){
    if($("#currentImg").attr("tag") == "true") return;
    if(mPage.ret.length !=0 ){
        mPage.ret[mPage.ret.length-1].view_time+=(new Date()).getTime();
        if(mPage.ret[mPage.ret.length-1].url == $("#currentImg")[0].src ) mPage.ret.pop();
    }
    mPage.ret.push( imageCreater.newImgX($("#currentImg"),$(".pic-title").text()) );
    if(debug1) console.log(mPage.ret[mPage.ret.length-1]);
    $("#currentImg").attr("tag","true");
}*/

