var imageCreater={
    newImg:function(e){
        var ret = {};
        ret.description = ($(e).attr("data-title")).replace("<strong>","").replace("</strong>","");
        ret.id = parseInt($("a",e).attr("name").match(/\d+/g)[0]);
        ret.data_feature = $("a",e).attr("href");
        ret.view_site = parseInt($("img",e).attr("viewSite"));
        ret.more_size = parseInt($("img",e).attr("moreSize"));
        ret.download_pic = parseInt($("img",e).attr("downloadPic"));
        ret = imageProcess(ret,$("img",e)[0]);
        ret.url = $("img",e).attr("data-imgurl");
        return ret;
    }
}

console.log("Baidu Main Page is Loaded!");

mPage.getUrl = function () {
    return window.location.href;
}

mPage.getQuery = function(){
    return $("#kw").val();
}

mPage.getPics = function() {
    var ret =new Array();
    $("#imgid .imgitem").each(function(id,e){
        ret.push(imageCreater.newImg(e));
    });
    return ret;
}

/**
 * 添加更多需要收集的信息
 * for each picture
 */
mPage.add = function(){
    console.log("DOM Change");
    $(".hover").each(function(id,e){
        if($(e).parent("img").attr("downloadPic") == undefined){
            $(e).parent("img").attr("downloadPic",0);
            $(".down",e).click({target:$("img",$(e).parent())[0]},mPage.onDownloadPic);
        }
        if($(e).parent("img").attr("viewSite") == undefined){
            $(e).parent("img").attr("viewSite",0);
            $(".title",e).click({target:$("img",$(e).parent())[0]},mPage.onViewSite);
        }
        if($(e).parent("img").attr("moreSize") == undefined){
            $(e).parent("img").attr("moreSize",0);
            $(".dutu",e).click({target:$("img",$(e).parent())[0]},mPage.onMoreSize);
        }
    });
}