/**
 * 图片类
 * url:图片的链接
 * description:图片的相关文字
 * top:上边沿
 * left:左边沿
 * width:展示宽度，单位为像素
 * height:展示高度，单位为像素
 * hover_time:鼠标悬停时间
 * hover_opt:hover操作序列 一个字符串
 * been_clicked:这张图片是否被点击过
 * view_site:用户是否查看过这张图片的来源网站
 * more_size:用户是否查看过这张图片更多尺寸
 * download_pic:用户是否下载了这张图片
 * id:图片编号(start from 0)
 * list_id:图片在OnePic中下恻滑动栏的标号
 * pre:滑动栏左边图片的id
 * next:滑动栏右侧的图片的id
 * data_feature:图片特征值，由此可以判断是否为同一张图片
 */

/**
 * 自动填充这张图片的需要的属性
 * @param {imageInfo} ret the final return
 * @param {object} obj a jQuery obj like: $("img")[0]
 */
function imageProcess(ret,obj){
    ret.url = $(obj)[0].src;
    ret.top = $(obj).offset().top;
    ret.left = $(obj).offset().left;
    ret.width = $(obj).width();
    ret.height = $(obj).height();
    ret.hover_time = $(obj).attr("hover-time");
    ret.hover_opt = $(obj).attr("hover-op");
    ret.been_clicked = parseInt($(obj).attr("beenClicked"));
    if(ret.hover_time == null) ret.hover_time = 0;
    if(ret.hover_opt == null) ret.hover_opt = "";
    if(ret.been_clicked == null || isNaN( ret.been_clicked )) ret.been_clicked = 0;
    if(ret.view_site == null || isNaN( ret.view_site )) ret.view_site=0;
    if(ret.more_size == null || isNaN( ret.more_size )) ret.more_size=0;
    if(ret.download_pic == null || isNaN( ret.download_pic )) ret.download_pic=0;
    if(ret.id == null || isNaN( ret.id )) ret.id=-233;
    if(ret.list_id == null || isNaN( ret.list_id )) ret.list_id=-233;
    if(ret.pre == null || isNaN( ret.pre )) ret.pre=-234;
    if(ret.next == null || isNaN( ret.next )) ret.next=-232;
    if(ret.data_feature == null) ret.data_feature="";
    return ret;
}

/**管理页面信息的接口 */
var mPage={

    /**
     * 返回值
     */
    ret:new Array(),

    /**
     * 获得当前页面链接
     */
    getUrl:function(){},

    /**
     * 返回当前页面所有图片相关信息
     * 如：图片链接，图片位置，图片文字说明，图片尺寸,鼠标悬停时间，是否被点击，展示时间等
     * 任务艰巨
     */
    getPics:function(){
        return mPage.ret;
    },

    /**
     * 获得当前搜索用关键字
     */
    getQuery:function(){},

    /**
     * 目前飘入没有飘出的对象
     */
    temp:null,
    
    /**
     * 鼠标飘入
     */
    hoverIn:function(){
        mPage.temp=$(this);
        var val=parseInt($(this).attr("hover-time"));
        val-=(new Date()).getTime();
        $(this).attr("hover-time",val);
        $(this).attr("hover-op",$(this).attr("hover-op")+"["+ (new Date()).getTime());
    },

    /**
     * 鼠标飘出
     */
    hoverOut:function(){
        if(mPage.temp == null) return false;
        var val=parseInt(mPage.temp.attr("hover-time"));
        val+=(new Date()).getTime();
        mPage.temp.attr("hover-time",val);
        mPage.temp.attr("hover-op",mPage.temp.attr("hover-op")+","+ (new Date()).getTime() +"]");
        mPage.temp=null;
    },

    /**
     * 被点击
     */
    click:function(e){
        $(e.currentTarget).attr("beenClicked",(new Date).getTime());
    },

    lastUpdate:0,
    /**
     * 更新页面的hover绑定
     * 在页面DOM树更新的时候触发
     */
    update:function(){
        var T = (new Date()).getTime();
        if(T-mPage.lastUpdate < 300) return;
        mPage.lastUpdate = T;
        if(debug1) console.log("update");
        $("img").each(function(id,e){
            if($(e).attr("hover-time") == undefined){
                $(e).attr("hover-time","0");
                $(e).attr("hover-op","");
                $(e).hover(mPage.hoverIn,mPage.hoverOut);
            }
            if($(e).attr("beenClicked") == undefined){
                $(e).attr("beenClicked",0);
                $(e).click(mPage.click);
            }
        })
        if(type == "mainPage" && mPage.add != undefined) mPage.add();
    },

    /**
     * 开始记录操作
     */
    start: function(){
        intervalKey = setInterval(bruteForce,BFInterval);
    },
    
    /**
     * 暂停记录操作
     */
    stop: function(){
        window.clearInterval(intervalKey);
    },

    viewSite: 0, //是否访问源网站
    moreSize: 0, //是否寻找更多大小
    downloadPic: 0, //是否下载图片
    viewOrigin: 0, //是否查看原图

    onDownloadPic:function(e = null){
        if(type == "onePic"){ 
            mPage.downloadPic = (new Date()).getTime();
            if(debug1) console.log("下载了图片");
        }else{
            if(e.data.target != null) e.currentTarget = e.data.target;
            $(e.currentTarget).attr("downloadPic",(new Date()).getTime());
            if(origin == "baidu" && type == "mainPage") viewState.life=1;
        }
    },
    onViewOrigin:function(e = null){
        if(type == "onePic"){ 
            mPage.viewOrigin = (new Date()).getTime();
            if(debug1) console.log("查看了原图");
        }else{
            if(e.data.target != null) e.currentTarget = e.data.target;
            $(e.currentTarget).attr("viewOrigin",(new Date()).getTime());
        }
    },
    onMoreSize:function(e = null){
        if(type == "onePic"){ 
            mPage.moreSize = (new Date()).getTime();
            if(debug1) console.log("查看了更多大小");
        }else{
            if(e.data.target != null) e.currentTarget = e.data.target;
            $(e.currentTarget).attr("moreSize",(new Date()).getTime());
        }
    },
    onViewSite:function(e = null){
        if(type == "onePic"){ 
            mPage.viewSite = (new Date()).getTime();
            if(debug1) console.log("查看了原网页");
        }else{
            if(e.data.target != null) e.currentTarget = e.data.target;
            $(e.currentTarget).attr("viewSite",(new Date()).getTime());
        }
    },
    clearState:function(e = null){
        mPage.viewSite = 0; //是否访问源网站
        mPage.moreSize = 0; //是否寻找更多大小
        mPage.downloadPic = 0; //是否下载图片
        mPage.viewOrigin = 0; //是否查看原图
    }

}

var intervalKey;
var BFInterval=20;//20ms
/**
 * 使用.val()修改属性我也没有办法啊
 * 根本没有可以监听的函数好吧
 * 我又不能重载它页面里的.val()，只能看到DOM树啊！！！
 * 绝望
 * 暴力出奇迹算了
 * 电脑差了跑不动别怪我
 * 尝试了一下午了，各种可能的方法都不行
 * dom change event
 * 可以响应，但是刚响应完新图片都没有加载好好吧
 * 图片位置是空的诶，怎么获取位置
 * 手动暴力得了
 * @param {object} e $(IMG)对象
 */
function bruteForce(){
    if(mPage.getImgObj == undefined) return;
    var newOne=imageCreater.newImgX( mPage.getImgObj() , mPage.getImgTitle() );
    if(mPage.ret.length != 0) newOne.view_time = mPage.ret[mPage.ret.length-1].view_time;
    if(mPage.ret.length != 0) newOne.start_timestamp = mPage.ret[mPage.ret.length-1].start_timestamp;
    if(mPage.ret.length != 0) newOne.end_timestamp = mPage.ret[mPage.ret.length-1].end_timestamp;
    if(mPage.ret.length == 0 || ( JSON.stringify(mPage.ret[mPage.ret.length-1]) != JSON.stringify(newOne) ) ){//append a new element
        if(debug1) console.log( newOne );
        newOne.view_time = 0;
        newOne.start_timestamp = newOne.end_timestamp = (new Date()).getTime();
        mPage.ret.push( newOne );
        mPage.clearState();
    }else{
        mPage.ret[mPage.ret.length-1].view_time+=BFInterval;
        mPage.ret[mPage.ret.length-1].end_timestamp = (new Date()).getTime();
    }
}

/**当前页面可见性 */
var viewState={
    /**
     * 当前状态
     * true 用户正在查看页面
     * false 用户切出页面以外 
     */
    show:true,

    /**
     * 上次操作时间
     */
    lastOp:0,
    
    /**
     * 超时时长
     * 如果用户超过这个时间没有任何动作，
     * 我们认为用户离开。
     * 当前时限：5s
     */
    timeLimit:5000,
    
    /**
     * 
     */
    check:function(){
        if(debug) console.log("check");
        if((new Date()).getTime() - viewState.lastOp >= viewState.timeLimit && viewState.show == true)
            viewState.toggleState();
        else if(viewState.show == true)
            setTimeout(viewState.check,viewState.timeLimit);
    },
    /**
     * 切换当前可见状态
     */
    toggleState: function(){
        if(debug) console.log("View State Changed from " + viewState.show + " to " + !viewState.show);
        if(viewState.show == false){
            viewState.show = true;
            viewState.check();
            surveyManager.getIn();
        }else{
            viewState.show = false;
            surveyManager.getOut();
        }
    },

    /**
     * 进入
     */
    getIn:function(){
        viewState.lastOp=(new Date()).getTime();
        if(viewState.show == false)
            viewState.toggleState();
    },

    /**
     * 离开
     */
    getOut:function(){
        if(viewState.show == true)
            viewState.toggleState();
    },

    /**
     * 用户有操作,为大图页面特殊监听的操作
     */
    action:function(){

    },

    /**
     * 标签栏切入页面响应的函数
     */
    tabEnter:function(){
        viewState.getIn();
    },

    /**
     * 标签栏切出页面响应的函数
     * 在页面关闭时也会响应
     * 会在 onbeforeunload 之后响应
     * 切入后台(alt+tab)不会响应，
     * 只有标签页切换才会响应
     */
    tabLeave:function(){
        viewState.getOut();
    },
    
    /**
     * 获得焦点
     * 如果同时出发tabEnter,会在tabEnter之后调用
     */
    focus:function(){
        viewState.getIn();
    },

    /**
     * 失去焦点
     * 比如鼠标点击地址栏或切入后台
     */
    blur:function(){
        if(debug) console.log("blur!");
        viewState.getOut();
    },

    /**
     * 鼠标在当前页面内移动了一下
     * @param {鼠标位置信息} e 
     */
    mMove:function(e){
        viewState.getIn();
        mRec.move(e);
    },

    /**
     *  鼠标滚轮滚动
     */
    mScroll:function(){
        viewState.getIn();
        mRec.scroll();
    },

    /**
     * 页面内容改变
     */
    change:function(){
        viewState.getIn();
    },

    /**
     * 剩余生命
     * 不知道为什么百度下载会出发关闭时间
     */
    life:0,
    /**
     * 页面关闭
     */
    close:function(){
        if(viewState.life > 0 ){
            viewState.life--;
            return;
        }
        viewState.getOut();
        surveyManager.close();
    },

    /**
     * 左键单击
     */
    lClick:function(){

    },

    /**
     * 键盘按下
     */
    keyDown:function(){

    },

    /**
     * 鼠标中键滚动
     */
    MidScroll:function(){

    }
}