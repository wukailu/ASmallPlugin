var postUrl = "https://www.image-feedback.com"
var username,password;
var version = "1.0.8";
var debug1 = false;
var downloadLink = "https://github.com/wukailu/ASmallPlugin";
var lastReminder = 0;

/**
 * 把消息存在LocalStorge
 * 并且返回相应的Key
 * @param {Message} Msg 需要储存的消息 
 */
function storgeInfo(Msg){
    var key=(new Date()).getTime();
    localStorage[""+key]=Msg;
    return ""+key;
}

/**
 * 传入Key,删除文件
 * @param {Number} key 用来删除东西用的 
 */
function deleteInfo(key){
    localStorage.removeItem(key);
}

/**
 * 把消息发给服务器
 * 首先储存这个消息，避免发送过程中被关掉导致数据丢失。
 * 发送完成后删除本地储存。
 * @param {Message} Msg 需要发给服务器的消息 
 */
function sendInfo(Msg){
    var a = JSON.parse(Msg).version;
    if(a != version) return;//drop this pack
    var key = storgeInfo(Msg);
    $.ajax({
        headers: {
            "Authorization": "Basic " + btoa(username + ":" + password)
        },
        type:"POST",
        url: postUrl + "/api/data",
        dataType:"text",
        data: Msg,
        contentType: "application/json; charset=utf-8",
        success: function(data){
            if(!debug1) deleteInfo(key);
        },
        error : function(jqXHR, textStatus, errorThrown){
            if(jqXHR.status == 400){//需要更新
                if((new Date()).getTime() - lastReminder < 10*60*1000 ) return;
                lastReminder = (new Date()).getTime();
                if(!debug1) deleteInfo(key);
                // 用户授权
                if (Notification.permission != "granted") {
                    window.open(downloadLink);
                }else{
                    var notification = new Notification('升级提醒', {
                        icon: 'https://www.silog.fr/wp-content/uploads/2015/04/Rouages-Grand.png',
                        body: "您的插件目前不是最新版，可能影响使用结果，请尽快更新。点击下载最新版本。"
                    });
                    notification.onclick = function () {
                        window.open(downloadLink);
                        //window.location.href = "http://on9i1rseh.bkt.clouddn.com/Extension/ASmallPlugin.crx"
                    };            
                }

            }
        }
    });
}

/**
 * 用来进行不同的通讯
 * 
 * content 会要求加载一些脚本
 * 
 * popup 会传递用户名和密码
 * 
 * basic 会要求发送所有信息
 */
chrome.runtime.onMessage.addListener(function(Msg, sender, sendResponse){
    if(Msg.file != undefined){
        chrome.tabs.executeScript(sender.tab.id,Msg,function(results){
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
                chrome.tabs.sendMessage(sender.tab.id, {scriptFinish:true}, function(response) {});  
            });
        });
        return;
    }else if(Msg.username != undefined && Msg.password != undefined){
        username = Msg.username;
        password = Msg.password;
        $.cookie("username",username);
        $.cookie("password",password);
    }
    if(Msg == null || !("wkl" in Msg)) return;//这是谁乱发的消息？？？ QAQ
    if(Msg.referrer.startsWith("https://www.image-feedback.com")) return;
    Msg.username = username;
    Msg.version = version;
    Msg.url = sender.tab.url;
    Msg=JSON.stringify(Msg);
    sendInfo(Msg);//交给发送吧
});

/**
 * 把以前没有发送成功的数据发送出去
 */
function flush(){
    for(var i = localStorage.length - 1; i >=0 ;i--){
        var lastkey = localStorage.key(i);
        var Msg = localStorage[lastkey];
        localStorage.removeItem(lastkey);
        sendInfo(Msg);
    }
}

function verifyUser(){
    if($.cookie('username') != "" && $.cookie('password') != "" ){
        var name = $.cookie('username');
        var psw = $.cookie('password');
            console.log("POSTing");
            var result = false;
        $.ajax
        ({
            type: "POST",
            url: postUrl + "/api/token",
            dataType: 'json',
            async: false,
            headers: {
                "Authorization": "Basic " + btoa(name + ":" + psw)
            },
            data: { query:"none" },
            success: function (data){
                chrome.runtime.sendMessage({username: name , password: psw});
                result = true;
            },
            error : function(data){
                result = false;
            }
        });
        }
        return result;
  }


username = $.cookie("username");
password = $.cookie("password");
if(!debug1) flush();
setInterval(verifyUser,86400000);