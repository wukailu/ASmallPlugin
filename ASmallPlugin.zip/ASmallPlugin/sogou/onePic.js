/**
 * 多check一下
 * 可能有BUG
 */

var imageCreater={
    /**
     * @param e a object to img
     * @param description the words
     */
    newImgX:function(e,description){//img_obj string
        var ret = {};
        ret.description = description;
        ret.view_time= 0;
        ret = imageProcess(ret,e[0]);
        ret = getIDs(ret);
        ret.hover_time=0;
        ret.hover_opt="";
        ret.view_site = mPage.viewSite;
        ret.more_size = mPage.moreSize;
        ret.download_pic = mPage.downloadPic;
        ret.view_origin = mPage.viewOrigin;
        return ret;
    }
}

function getIDs(ret){
    var t = mPage.getUrl().match(/\d+/g);
    var d1=parseInt(t[t.length-2])-1, d2=parseInt(t[t.length-1]);
    ret.list_id = d2;
    if(mPage.getUrl().match("&phu") == null){
        ret.id = d2;
        ret.pre = ret.id-1;
        ret.next = ret.id+1;
    }else if(d2 == 0){
        ret.id = d1;
        ret.pre = -1;
        ret.next = 1==d1 ? 0:1;
    }else{
        ret.id = d2==d1 ? 0:d2;
        ret.pre = d2-1==d1 ? 0:d2-1;
        ret.next = d2+1==d1 ? 0:d2+1;
    }
    return ret;
}

console.log("Sogou onePic is Loaded!");

mPage.getUrl = function () {
    return window.location.href;
}

mPage.getQuery = function(){
    return $("#form_querytext").val();
}

mPage.getImgObj = function(){
    return $("#imageBox img");
}

mPage.getImgTitle = function(){
    return $("#imageTitle").text();
}

$("#saveToPc").click(mPage.onDownloadPic);
$("#imageInfo a").click(mPage.onViewOrigin);
$("#shituBtn").click(mPage.onMoreSize);
$(".link a").click(mPage.onViewSite);
$("#imageTitle").click(mPage.onViewSite);
$("#imageBox img").click(mPage.onViewSite);