/**这个是最终要发给服务器的数据 */
var msg={
    /**标记而已 */
    wkl:"2333",
    /**
     * 页面类型
     * query 预览界面
     * clicked_image 单独一个图片的详细页面
     */
    type:"",
    /**
     * 开始创建时间
     * 单位ms
     */
    start_timestamp:0,
    /**
     * 结束浏览时间
     * 单位ms
     */
    end_timestamp:0,
    /**
     * 浏览总时间
     * 单位ms
     */
    dwell_time:0,
    /**
     * 索搜关键词
     */
    keyword:"zhongwen",
    /**
     * 搜索网页链接
     */
    url:"",
    /**
     * 所有相关图片的链接和附带的简介
     * 如果有主次关系，那么第一张图片为最重要的图片
     * 为一个图片数组
     */
    images:null,
    /**
     * 一个mouseMove的数组
     * 记录了鼠标此过程中的所有移动信息
     * 以及滑轮的信息
     */
    mouse_moves:null,
    
    /**
     * 保留页面整体的HTML以用于以后使用
     */
    html:null,

    /**
     * 来源网址
     */
    referrer:"",

    /**
     * 用户名
     */
    username:"",

    /**
     * 当前版本
     */
    version:"",
}



var surveyManager={
    /**
     * 上次查看这个页面的时间
     */
    lastViewTime:0,

    /**
     * 开启一次搜索
     */
    initialize:function(){
        msg.start_timestamp=(new Date()).getTime();
        surveyManager.lastViewTime=msg.start_timestamp;
        mPage.start();
    },
    /**
     * 用户开始查看这个页面
     */
    getIn:function(){
        surveyManager.lastViewTime=(new Date()).getTime();
        mPage.start();
    },

    /**
     * 用户不再查看当前页面
     */
    getOut:function(){//切出页面
        msg.end_timestamp=(new Date()).getTime();
        msg.dwell_time+=msg.end_timestamp-surveyManager.lastViewTime;
        surveyManager.lastViewTime=msg.end_timestamp;
        mRec.pause();
        mPage.hoverOut();
        mPage.stop();
    },


    /**
     * 用户关闭这个页面
     */
    close:function(){
        msg.referrer = document.referrer;
        msg.html=pako.deflate(document.documentElement.outerHTML, { to: 'string' });
        mRec.end();
        msg.images=mPage.getPics();
        msg.mouse_moves= pako.deflate(JSON.stringify( mRec.getData()) , { to: 'string' });//以GZIP的格式压缩文件
        chrome.runtime.sendMessage(msg);
        mPage.stop();
    },
}
