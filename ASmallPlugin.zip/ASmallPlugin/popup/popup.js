var postUrl = "https://www.image-feedback.com"
var downloadLink = "https://github.com/wukailu/ASmallPlugin";

function userTab(){
  $("#failMsg").hide();
  $("#login").hide();
  $("#logged").show();
}

function loginTab(){
  $("#logged").hide();
  $("#failMsg").hide();
  $("#login").show();
}

function trylogin(){
  console.log("logging...");
  localStorage['password']=""+$("#psw").val();
  localStorage['username']=""+$("#usrname").val();
  if(verifyUser() == true){
    userTab();
  }else{
    $("#failMsg").show();
  }
  localStorage[1]=21;
  localStorage[2]=22;
}

function verifyUser(){
  console.log("checking");
  if(localStorage['username'] != undefined && localStorage['password'] != undefined ){
    var name = localStorage['username'];
    var psw = localStorage['password'];
		console.log("POSTing");
		var result = false;
    $.ajax
    ({
        type: "POST",
        url: postUrl + "/api/token",
        dataType: 'json',
        async: false,
        headers: {
            "Authorization": "Basic " + btoa(name + ":" + psw)
        },
        data: { query:"none" },
        success: function (data){
						chrome.runtime.sendMessage({username: name , password: psw});
						result = true;
        },
        error : function(){
            result = false;
        }
    });
	}
	return result;
}

function feedback(){
  window.open(postUrl);
}
function download(){
  window.open(downloadLink,'_blank');
}
function logout(){
  localStorage['username'] = null;
  localStorage['password'] = null;
  location.reload();
}

if(jQuery){
	loginTab();
	$("#bt1").click(trylogin);
  $("#bt2").click(feedback);
  $("#bt3").click(download);
  $("#bt4").click(logout);
	if(verifyUser() == true)
		userTab();
}else{
	console.log("jQuery is needed!");
}


