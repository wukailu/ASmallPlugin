var debug = false;
var debug1 = false;

/**
 * 执行初始化
 */
var origin = "???",type = "???";
var temp = window.location.host.match(/(baidu)?(sogou)?(so)?\.com/g)[0];
switch (temp) {
    case "sogou.com":
        origin = "sogou";
        switch (window.location.pathname) {
            case "/pics":
                type = "mainPage";
                break;
            case "/d":
                type = "onePic";
                break;
            default:
                break;
        }

        break;

    case "baidu.com":
        origin = "baidu";
        switch (window.location.pathname) {
            case "/search/index":
                type = "mainPage";
                break;
            case "/search/detail":
                type = "onePic";
                break;
            default:
                break;
        }
        break;

    case "so.com":
        origin = "360";
        switch (window.location.pathname) {
            case "/i":
                type = "mainPage";
                break;
            case "/v":
                type = "onePic";
                break;
            default:
                break;
        }
        break;
    default:
        break;
}

if(debug){ 
console.log("content is loaded");
console.log("origin="+ origin + "  " + "type=" + type);
console.log(viewState);
}

if(origin != "???" && type != "???"){

    if(debug) console.log("extension is started");

    msg.type = (type == "mainPage") ? "query":"clicked_image";
    
    /*$.getScript(chrome.extension.getURL(origin + "/" + type + ".js"), function() {
        //alert("Script loaded but not necessarily executed.");
        msg.url=mPage.getUrl();
        msg.keyword=mPage.getQuery();
    });*/
    /**
     * 页面可见性变化
     */
    document.addEventListener("visibilitychange", function(event){
        var hidden = event.target.webkitHidden;  
        if (hidden) viewState.tabLeave();  
        else viewState.tabEnter();
    }, false);

    window.onbeforeunload = viewState.close;
    $(window).focus(viewState.focus);
    $(window).blur(viewState.blur);
    $(window).mousemove(viewState.mMove);
    $(window).scroll(viewState.mScroll);
    viewState.lastOp=(new Date()).getTime();
    $(window).bind('DOMNodeInserted', function(e) {
        mPage.update();
        viewState.change();
    });
    $(document).ready(function(){
        surveyManager.initialize();
        viewState.check();
    });
    chrome.runtime.onMessage.addListener(function(Msg, sender, sendResponse){
        if(Msg.scriptFinish == true){
            msg.referrer = document.referrer;
            msg.url=mPage.getUrl();
            msg.keyword=mPage.getQuery();
            mPage.update();
        }
    });
    chrome.runtime.sendMessage({file: origin + "/" + type + ".js"});

    if(debug){
        $(window).mousedown(function(e){
            mRec.replay();
        });
    } 
    console.log("initialize down!");
}


    