var imageCreater={
    newImg:function(e){
        var ret = {};
        ret.description = $(".img_link",e).text();
        imageProcess(ret,$("img",e)[0]);
        ret.id = parseInt($("img",e).attr("data-index"));
        ret.data_feature = ret.url;
        ret.view_site = parseInt($(".img_tit a",e).attr("viewSite"));
        ret.more_size = parseInt($(".st_info a",e).attr("moreSize"));
        return ret;
    }
}

console.log("360 Main Page is Loaded!");

mPage.getUrl = function () {
    return window.location.href;
}

mPage.getQuery = function(){
    return $("#search_kw").val();
}

mPage.getPics = function() {
    var ret =new Array();
    $("#waterfallX li").each(function(id,e){
        if($(e).attr("class") != "diver-cell")
            ret.push(imageCreater.newImg(e));
    });
    return ret;
}

/**
 * 添加更多需要收集的信息
 * for each picture
 */
mPage.add = function(){
    $(".img_tit a").each(function(id,e){
        if($(e).attr("viewSite") == undefined){
            $(e).attr("viewSite",0);
            $(e).click(mPage.onViewSite);
        }   
    });
    $(".st_info a").each(function(id,e){
        if($(e).attr("moreSize") == undefined){
            $(e).attr("moreSize",0);
            $(e).click(mPage.onMoreSize);
        }   
    });
}