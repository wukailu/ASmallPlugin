var mRec={
    //---以下为重新播放刚刚的操作的部分
    controlMouse:function(x,y){
        $("#box").attr("style","left:"+x+"px;top:"+y+"px;position:absolute;width:20px;height:20px;background:red;z-index:999999;");
    },
    controlScroll:function(x,y){
        window.scrollTo(x,y);
    },
    /**
     * @param {aMove} move
     * @param {number} t0
     * @param {function} controller
     */
    reRun:function(move,t0,controller){
        var tnow=(new Date()).getTime()-t0;
        var dx=(move.Ex-move.Sx)/(move.Et-move.St)*tnow;
        var dy=(move.Ey-move.Sy)/(move.Et-move.St)*tnow;
        controller(move.Sx+dx,move.Sy+dy);
    },
    replayLine:function(move,controler){
        var key =setInterval(mRec.reRun,10,move,(new Date()).getTime(),controler);
        setTimeout(function(key){window.clearInterval(key)},move.Et-move.St,key);
    },
    /**
     * 重放刚刚录制的操作
     * moveRec = mRec.movePath.getData()
     * scrollRec = mRec.scrollPath.getData()
     */
    replay:function(moveRec,scrollRec,time0){
        $("body").append('<div id="box" style="left: 43px; top: 47px;position:absolute;width:10px;height:10px;background:red;z-index:999999;"></div>')
        var moveT0=1e18,scrollT0=1e18;
        if(moveRec != undefined){
            moveRec.forEach(function(e,id){
                setTimeout(mRec.replayLine,e.St-time0,e,mRec.controlMouse);
            });
        }
        if(scrollRec != undefined){
            scrollRec.forEach(function(e,id){
                setTimeout(mRec.replayLine,e.St-time0,e,mRec.controlScroll);
            });
        }
    }
}
