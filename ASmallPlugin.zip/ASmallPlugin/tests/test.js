/**
     * 初始化操作播放器
     * 将数据复原到Msg压缩前
     */
var replay = function(Msg){
    Msg.mouse_moves = JSON.parse(pako.inflate(Msg.mouse_moves, { to: 'string' }));
    var idcnt=0;
    for(var img in Msg.images){
        var insert = document.createElement("img");
        insert.style.width = img.width;
        insert.style.height = img.height;
        insert.style.position = "absolute";
        insert.style.left = img.left;
        insert.style.top = img.top;
        insert.title = img.description;
        insert.src = img.url;
        insert.id = idcnt++;
        var posx = img.left + img.width/2;
        var posy = img.top + img.height/2;
        if(img.been_clicked != 0) showMsg(posx,posy,"clicked",img.been_clicked-Msg.start_timestamp);
        if(img.download_pic != 0) showMsg(posx,posy,"downloaded",img.download_pic-Msg.start_timestamp);
        if(img.view_site != 0) showMsg(posx,posy,"viewed",img.view_site-Msg.start_timestamp);
        $("body").append(insert);
        if(img.view_time != undefined) setTimeout((id) => {
            $("#"+id).remove();
        }, img.view_time,insert.id);
    }
    var index = 0;
    while(index<Msg.mouse_moves.length && Msg.mouse_moves[index].Ty=="Move") index++;
    var mouseMove,scrollMove;
    if(Msg.mouse_moves[0].Ty == "Move") mouseMove=Msg.mouse_moves.slice(0,index);
    if(index < Msg.mouse_moves.length) scrollMove=Msg.mouse_moves.slice(index,Msg.mouse_moves.length);
    document.title = "user:"+Msg.username+" keyword:"+Msg.keyword;
    setTimeout(CloseWebPage, Msg.end_timestamp - Msg.start_timestamp);
}


function showMsg(x,y,word,time){//展示一秒

}

function CloseWebPage(){
    if (navigator.userAgent.indexOf("MSIE") > 0) {
        if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
        window.opener = null;
        window.close();
        } else {
        window.open('', '_top');
        window.top.close();
        }
    }
    else if (navigator.userAgent.indexOf("Firefox") > 0) {
        window.location.href = 'about:blank ';
    } else {
        window.opener = null;
        window.open('', '_self', '');
        window.close();
    }
}