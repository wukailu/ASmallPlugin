var imageCreater={
    newImg:function(e){
        var ret = {};
        ret.description = $("p",e).text();
        ret = imageProcess(ret,$("img",e)[0]);
        ret.id = imageCreater.count++;
        ret.data_feature = null;
        return ret;
    }
}

console.log("Sogou Main Page is Loaded!");

mPage.getUrl = function () {
    return window.location.href;
}

mPage.getQuery = function(){
    return $("#form_querytext").val();
}

mPage.getPics = function() {
    imageCreater.count = 0;
    var ret =new Array();
    $("#imgid li").each(function(id,e){
        ret.push(imageCreater.newImg(e));
    });
    return ret;
}

/**
 * 添加更多需要收集的信息
 * for each picture
 */
mPage.add = function(){
}