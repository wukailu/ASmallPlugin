
var imageCreater={
    /**
     * @param e a object to img
     * @param description the words
     */
    newImgX:function(e,description){//img_obj string
        var ret = {};
        ret.description = description;
        ret.view_time= 0;
        ret = imageProcess(ret,e[0]);
        ret = getIDs(ret);
        ret.hover_time=0;
        ret.hover_opt="";
        ret.view_site = mPage.viewSite;
        ret.more_size = mPage.moreSize;
        ret.download_pic = mPage.downloadPic;
        ret.view_origin = mPage.viewOrigin;
        return ret;
    }
}

function getIDs(ret){
    var t = parseInt(mPage.getUrl().match(/&jdx=\d+/)[0].match(/\d+/)[0]);
    ret.list_id = t;
    if(document.referrer.match(/\/i\?/) != null){
        ret.id = t;
        ret.pre = t-1;
        ret.next = t+1;
    }else{
        //TODO
        /**
         * 当点击了右侧一张图片后
         * 新的图片顺序非常的奥妙重重
         * 与原有图片顺序完全不一致
         * 而且有些图片在原有大界面可能还没有出现
         * 还要往后翻好几页
         * 估计可能是个顺序推荐系统
         */
    }
    ret.data_feature = $(".lb_mainimg").attr("data-src");
    return ret;
}

console.log("360 onePic is Loaded!");

mPage.getUrl = function () {
    return window.location.href;
}

mPage.getQuery = function(){
    return $("#search_kw").val();
}

mPage.getImgObj = function(){
    return $(".lb_mainimg");
}

mPage.getImgTitle = function(){
    return $(".search-view").text();
}

$("#lbDownload").click(mPage.onDownloadPic);
$("#lb_st_btn").click(mPage.onMoreSize);
$("#imgSize").click(mPage.onMoreSize);
$("#imgRefer").click(mPage.onViewSite);
$(".search-view").click(mPage.onViewSite);
$(".lb_imgbox").click(mPage.onViewSite);